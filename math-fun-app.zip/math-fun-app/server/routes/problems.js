const express = require('express');
const Problem = require('../models/Problem');
const router = express.Router();

router.get('/', async (req, res) => {
    const { topic } = req.query;
    const problems = await Problem.findOne({ topic });
    res.json(problems || {});
});

router.post('/', async (req, res) => {
    const problem = new Problem(req.body);
    await problem.save();
    res.json(problem);
});

module.exports = router;