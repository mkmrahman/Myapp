const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const AdminJS = require('adminjs'); // নতুন
const AdminJSExpress = require('@adminjs/express'); // নতুন
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

// AdminJS সেটআপ
const Problem = require('./models/Problem');
const Quiz = require('./models/Quiz');
const User = require('./models/User');
const adminJs = new AdminJS({
    resources: [Problem, Quiz, User],
    rootPath: '/admin'
});
const router = AdminJSExpress.buildRouter(adminJs);
app.use(adminJs.options.rootPath, router);

// আগের রুটস...
app.listen(3000, () => console.log('Server running on port 3000'));