const mongoose = require('mongoose');

const ProblemSchema = new mongoose.Schema({
    topic: String,
    title: { bn: String, en: String },
    formulas: [{ name: { bn: String, en: String }, formula: String }],
    examples: [{ problem: String, solution: String }],
    shortcuts: [{ bn: String, en: String }],
    tricks: [{ bn: String, en: String }]
});

module.exports = mongoose.model('Problem', ProblemSchema);