const mongoose = require('mongoose');

const QuizSchema = new mongoose.Schema({
    topic: String,
    question: String,
    options: [String],
    answer: String
});

module.exports = mongoose.model('Quiz', QuizSchema);