async function addContent() {
    const topic = document.getElementById('topic').value;
    const problem = document.getElementById('problem').value;
    const solution = document.getElementById('solution').value;
    const token = localStorage.getItem('token'); // অ্যাডমিন অথেনটিকেশন চেক
    if (!token) {
        alert('অ্যাডমিন লগইন করুন!');
        return;
    }
    const response = await fetch(`${API_URL}/problems`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic, examples: [{ problem, solution }] })
    });
    if (response.ok) {
        alert('কনটেন্ট যোগ করা হয়েছে!');
        loadAdminContent();
    }
}

async function loadAdminContent() {
    const response = await fetch(`${API_URL}/problems`);
    const data = await response.json();
    document.getElementById('adminContent').innerHTML = `
        <h4>বর্তমান কনটেন্ট</h4>
        ${data.map(p => `<div class="card m-2"><div class="card-body">${p.topic}: ${p.examples[0]?.problem}</div></div>`).join('')}
    `;
}

loadAdminContent();