const API_URL = 'http://localhost:3000/api';

// আগের কোড (ভাষা টগল, লগইন, ইত্যাদি)...

// উন্নত কনটেন্ট লোড (আগের loadContent ফাংশন আপডেট)
async function loadContent(topic) {
    // আগের কোড...
    if (topic === 'geometry') {
        drawD3Visualization(); // D3.js কল
        drawThreeJS(); // Three.js কল
    }
    if (topic === 'statistics') {
        drawProgressChart(); // Chart.js কল
    }
    if (topic === 'quiz') {
        loadMultipleQuizzes(); // মাল্টিপল কুইজ
    }
}

// সমাধান অ্যানিমেশন
function solveProblem() {
    const input = document.getElementById('inputProblem').value;
    const solutionDiv = document.getElementById('solution');
    try {
        const result = math.evaluate(input);
        const steps = `Step 1: Calculate ${input}<br>Step 2: Result = ${result}`;
        solutionDiv.innerHTML = steps;
        solutionDiv.classList.add('animated-steps', 'show');
        // ধাপে ধাপে অ্যানিমেট
        setTimeout(() => {
            const stepElements = solutionDiv.querySelectorAll('br');
            stepElements.forEach((_, i) => {
                setTimeout(() => stepElements[i].classList.add('step-animation'), i * 500);
            });
        }, 500);
        MathJax.typeset();
    } catch (e) {
        // ত্রুটি হ্যান্ডলিং...
    }
}

// D3.js 3D ভিজুয়ালাইজেশন (জ্যামিতির জন্য)
function drawD3Visualization() {
    const width = 400, height = 400;
    const svg = d3.select("#d3Viz").append("svg").attr("width", width).attr("height", height);
    // সাধারণ 3D প্রজেকশন (d3-3d ব্যবহার)
    const projection = d3._3dprojection()
        .scale(150)
        .translate([width/2, height/2, 0])
        .rotateY(0)
        .rotateX(0);
    // উদাহরণ: একটি কিউব অঙ্কন
    const vertices = [
        [0,0,0], [0,0,1], [0,1,0], [0,1,1],
        [1,0,0], [1,0,1], [1,1,0], [1,1,1]
    ];
    // আরও বিস্তারিত কোড d3-3d ডকুমেন্টেশন অনুসারে...
}

// Three.js 3D শেপস
function drawThreeJS() {
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, 400/400, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer();
    renderer.setSize(400, 400);
    document.getElementById('threeViz').appendChild(renderer.domElement);
    
    const geometry = new THREE.BoxGeometry();
    const material = new THREE.MeshBasicMaterial({ color: 0x00ff00 });
    const cube = new THREE.Mesh(geometry, material);
    scene.add(cube);
    
    camera.position.z = 5;
    function animate() {
        requestAnimationFrame(animate);
        cube.rotation.x += 0.01;
        cube.rotation.y += 0.01;
        renderer.render(scene, camera);
    }
    animate();
}

// মাল্টিপল কুইজ এবং স্কোরবোর্ড
async function loadMultipleQuizzes() {
    const response = await fetch(`${API_URL}/quizzes`);
    const quizzes = await response.json();
    const contentDiv = document.getElementById('content');
    contentDiv.innerHTML = `
        <h4>কুইজ নির্বাচন করুন</h4>
        ${quizzes.map((quiz, i) => `
            <div class="quiz-card card m-2">
                <div class="card-body">
                    <h5>কুইজ ${i+1}: ${quiz.topic}</h5>
                    <p>${quiz.question}</p>
                    ${quiz.options.map(opt => `<button class="btn btn-outline-primary m-1" onclick="answerQuiz(${i}, '${opt}', '${quiz.answer}')">${opt}</button>`).join('')}
                </div>
            </div>
        `).join('')}
        <div id="scoreboard" class="mt-3"></div>
    `;
}

let scores = {};
function answerQuiz(quizId, selected, correct) {
    scores[quizId] = selected === correct ? 1 : 0;
    updateScoreboard();
}

function updateScoreboard() {
    const total = Object.values(scores).reduce((a, b) => a + b, 0);
    document.getElementById('scoreboard').innerHTML = `<h5>স্কোর: ${total}/${Object.keys(scores).length}</h5>`;
}

// Chart.js এনালিটিক্স চার্ট
let progressChart;
function drawProgressChart() {
    const ctx = document.getElementById('progressChart').getContext('2d');
    progressChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['কুইজ সম্পন্ন', 'সঠিক উত্তর'],
            datasets: [{ label: 'প্রোগ্রেস', data: [5, 8], backgroundColor: ['#007bff', '#28a745'] }]
        },
        options: { animation: true }
    });
}

// অন্যান্য ইভেন্ট লিসেনার (আগের মতো)...